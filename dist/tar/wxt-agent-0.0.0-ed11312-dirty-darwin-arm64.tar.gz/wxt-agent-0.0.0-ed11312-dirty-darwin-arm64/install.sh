#!/bin/bash
set -e

echo "Installing wxt-agent..."

# Install binary
sudo cp wxt-agent /usr/local/bin/
sudo chmod +x /usr/local/bin/wxt-agent

# The agent looks for the session helper NEXT TO ITSELF, so both binaries have
# to land in the same directory. Without it remote control cannot start.
if [ -f wxt-agent-session ]; then
    sudo cp wxt-agent-session /usr/local/bin/
    sudo chmod +x /usr/local/bin/wxt-agent-session
    echo "✓ Session helper installed (needed for remote control)"
fi

echo "✓ Installation complete!"
echo ""
echo "To configure: wxt-agent configure --help"
echo ""
echo "For remote control, grant wxt-agent-session both Screen Recording and"
echo "Accessibility under System Settings > Privacy & Security. macOS will not"
echo "grant these silently."
