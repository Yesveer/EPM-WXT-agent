VSay Agent 1.0.0-ed11312-dirty for Windows

CONTENTS:
  wxt-agent.exe          the agent daemon
  wxt-agent-session.exe  the session helper, required for remote control.
                         It MUST sit in the same folder as wxt-agent.exe.

INSTALLATION:
Right-click "install.bat" and select "Run as administrator"

USAGE:
  wxt-agent configure --help
  wxt-agent start --config C:\ProgramData\VSay\agent.yaml

Visit: https://vsay.in
