# VSay Agent Installer for Windows
$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  VSay Agent Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "This installer requires Administrator privileges." -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Installing VSay Agent..." -ForegroundColor Green

$installDir = "C:\Program Files\VSay"
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
}

Copy-Item -Path ".\wxt-agent.exe" -Destination "$installDir\wxt-agent.exe" -Force

# The session helper must live beside the agent — that is where the agent
# looks for it when an admin starts a remote-control session.
if (Test-Path ".\wxt-agent-session.exe") {
    Copy-Item -Path ".\wxt-agent-session.exe" -Destination "$installDir\wxt-agent-session.exe" -Force
    Write-Host "Session helper installed (required for remote control)" -ForegroundColor Green
}

$currentPath = [Environment]::GetEnvironmentVariable("Path", "Machine")
if ($currentPath -notlike "*$installDir*") {
    [Environment]::SetEnvironmentVariable("Path", "$currentPath;$installDir", "Machine")
}

$configDir = "C:\ProgramData\VSay"
if (-not (Test-Path $configDir)) {
    New-Item -ItemType Directory -Path $configDir -Force | Out-Null
}

Write-Host ""
Write-Host "Installation complete!" -ForegroundColor Green
Write-Host "Open a NEW terminal and run: wxt-agent configure --help"
Read-Host "Press Enter to exit"
